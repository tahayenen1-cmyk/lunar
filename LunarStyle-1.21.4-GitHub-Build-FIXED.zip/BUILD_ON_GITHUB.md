# Telefonda derleme

Bu proje GitHub Actions ile bilgisayarsız derlenebilir.

1. GitHub'da yeni bir repository oluştur.
2. Bu ZIP'in içindeki dosyaları repository'ye yükle.
3. GitHub'da **Actions** sekmesine gir.
4. **Build LunarStyle** workflow'unu seç.
5. **Run workflow** seçeneğine bas.
6. İşlem bitince workflow'un **Artifacts** bölümünden `LunarStyle-1.21.4` dosyasını indir.
7. İçindeki `.jar` dosyası Minecraft 1.21.4 + Fabric için moddur.

Not: Bu proje Lunar Client'ın kapalı kaynak/proprietary modüllerini içermez; bağımsız bir Fabric mod iskeletidir.
