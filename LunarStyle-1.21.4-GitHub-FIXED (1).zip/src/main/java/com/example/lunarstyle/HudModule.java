package com.example.lunarstyle;

import net.minecraft.client.MinecraftClient;

public class HudModule implements Module {
    private final String name;
    private boolean enabled = true;

    public HudModule(String name) { this.name = name; }
    public String name() { return name; }
    public boolean enabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public void tick(MinecraftClient client) { }
}