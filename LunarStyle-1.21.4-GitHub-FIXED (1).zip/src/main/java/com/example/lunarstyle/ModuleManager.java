package com.example.lunarstyle;

import net.minecraft.client.MinecraftClient;
import java.util.*;

public class ModuleManager {
    private final Map<String, Module> modules = new LinkedHashMap<>();
    private boolean hudVisible = true;

    public void register(Module module) { modules.put(module.name(), module); }
    public Collection<Module> all() { return Collections.unmodifiableCollection(modules.values()); }
    public Module get(String name) { return modules.get(name); }
    public void toggleHud() { hudVisible = !hudVisible; }
    public boolean hudVisible() { return hudVisible; }

    public void tick(MinecraftClient client) {
        for (Module m : modules.values()) if (m.enabled()) m.tick(client);
    }
}