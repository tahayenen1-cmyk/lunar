package com.example.lunarstyle;

import net.minecraft.client.MinecraftClient;

public class ToggleSprintModule extends HudModule {
    public ToggleSprintModule() { super("Toggle Sprint"); }

    @Override public void tick(MinecraftClient client) {
        if (client.player != null && client.options.forwardKey.isPressed()) {
            client.player.setSprinting(true);
        }
    }
}