package com.example.lunarstyle;

import net.minecraft.client.MinecraftClient;

public class ZoomModule extends HudModule {
    public ZoomModule() { super("Zoom"); }

    @Override public void tick(MinecraftClient client) {
        // Zoom rendering/key handling can be added with a mixin or FOV option hook.
    }
}