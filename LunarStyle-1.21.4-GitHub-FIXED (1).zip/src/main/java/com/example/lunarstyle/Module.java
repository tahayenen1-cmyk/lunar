package com.example.lunarstyle;

import net.minecraft.client.MinecraftClient;

public interface Module {
    String name();
    boolean enabled();
    void setEnabled(boolean enabled);
    void tick(MinecraftClient client);
}