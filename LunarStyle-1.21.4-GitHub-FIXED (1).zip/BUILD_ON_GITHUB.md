# LunarStyle 1.21.4 — GitHub'da derleme

Bu sürümde önceki Gradle hatası düzeltildi:
- Fabric Loom 1.9.2 için Gradle 8.11 kullanılıyor.
- Java 21 kullanılıyor.
- GitHub Actions JAR dosyasını otomatik olarak Artifact olarak yükler.

## Telefonda
1. Bu ZIP'i indir.
2. GitHub'da repository'ni aç.
3. ZIP içindeki dosyaları repository'ye yükle.
4. `.github/workflows/build.yml` dosyasının bulunduğundan emin ol.
5. **Actions → Build LunarStyle → Run workflow** seç.
6. Build yeşil olursa **Artifacts** bölümünden `LunarStyle-1.21.4` dosyasını indir.
7. İçindeki `.jar` dosyasını Minecraft 1.21.4 + Fabric mods klasörüne koy.

Not: Bu proje Lunar Client'ın kapalı kaynak/proprietary kodlarını içermez; bağımsız bir Fabric mod projesidir.
