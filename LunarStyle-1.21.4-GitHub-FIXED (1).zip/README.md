# LunarStyle — Minecraft 1.21.4

A clean-room Fabric starter implementing Lunar-style client features without copying Lunar Client code.

## Included module registry
Keystrokes, CPS, FPS, Ping, Coordinates, Armor, Potions, Direction, Combo, Crosshair, Toggle Sprint, Zoom.

The HUD modules are intentionally lightweight placeholders so each feature can be implemented independently.

## Build
1. Install Java 21.
2. Open this folder in IntelliJ IDEA with the Gradle project imported.
3. Run `./gradlew build` (Windows: `gradlew.bat build`).
4. The mod JAR will be in `build/libs/`.

Minecraft 1.21.4 development uses Fabric Loom and Fabric Loader; Fabric's 1.21.4 guidance originally recommended Loom 1.9 and Loader 0.16.9.
