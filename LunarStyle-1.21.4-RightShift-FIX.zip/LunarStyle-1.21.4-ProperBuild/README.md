# LunarStyle 1.21.4

Fabric client mod project. Right Shift opens the LunarStyle menu.

## Build
Run `gradle build` with Java 21 and Fabric Loom. The GitHub Actions workflow should build this project and upload the JAR artifact.

## Controls
- Right Shift: open LunarStyle menu
- Options -> Controls -> Key Binds -> LunarStyle Menu: configurable keybind
