package com.example.lunarstyle;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class LunarStyleClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static KeyBinding menuKey;
    private static boolean rightShiftDown = false;

    @Override
    public void onInitializeClient() {
        MODULES.register(new HudModule("Keystrokes"));
        MODULES.register(new HudModule("CPS"));
        MODULES.register(new HudModule("FPS"));
        MODULES.register(new HudModule("Ping"));
        MODULES.register(new HudModule("Coordinates"));
        MODULES.register(new HudModule("Armor"));
        MODULES.register(new HudModule("Potions"));
        MODULES.register(new HudModule("Direction"));
        MODULES.register(new HudModule("Combo"));
        MODULES.register(new HudModule("Crosshair"));
        MODULES.register(new ToggleSprintModule());
        MODULES.register(new ZoomModule());

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lunarstyle.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.lunarstyle"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Primary path: Fabric keybinding API.
            while (menuKey.wasPressed()) {
                openMenu(client);
            }

            // Fallback path: directly watch the physical Right Shift key.
            // This makes the menu work even if another mod/input layer interferes
            // with keybinding press events.
            if (client.getWindow() != null) {
                boolean down = InputUtil.isKeyPressed(
                        client.getWindow().getHandle(),
                        GLFW.GLFW_KEY_RIGHT_SHIFT
                );
                if (down && !rightShiftDown) {
                    openMenu(client);
                }
                rightShiftDown = down;
            }

            MODULES.tick(client);
        });
    }

    private static void openMenu(MinecraftClient client) {
        if (client.currentScreen == null) {
            client.setScreen(new LunarStyleScreen());
        }
    }
}
