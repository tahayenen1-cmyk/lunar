package com.example.lunarstyle;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class LunarStyleClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        MODULES.register(new HudModule("Keystrokes"));
        MODULES.register(new HudModule("CPS"));
        MODULES.register(new HudModule("FPS"));
        MODULES.register(new HudModule("Ping"));
        MODULES.register(new HudModule("Coordinates"));
        MODULES.register(new HudModule("Armor"));
        MODULES.register(new HudModule("Potions"));
        MODULES.register(new HudModule("Direction"));
        MODULES.register(new HudModule("Combo"));
        MODULES.register(new HudModule("Crosshair"));
        MODULES.register(new ToggleSprintModule());
        MODULES.register(new ZoomModule());

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lunarstyle.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.lunarstyle"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new LunarStyleScreen());
            }
            MODULES.tick(client);
        });
    }
}
