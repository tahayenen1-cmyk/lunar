package com.example.lunarstyle;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class LunarStyleScreen extends Screen {
    public LunarStyleScreen() {
        super(Text.literal("LunarStyle"));
    }

    @Override
    protected void init() {
        int buttonWidth = 190;
        int x = Math.max(10, (this.width - buttonWidth) / 2);
        int y = 45;
        int i = 0;

        for (Module module : LunarStyleClient.MODULES.all()) {
            final Module m = module;
            String label = m.name() + ": " + (m.enabled() ? "ON" : "OFF");
            this.addDrawableChild(ButtonWidget.builder(Text.literal(label), button -> {
                m.setEnabled(!m.enabled());
                this.clearAndInit();
            }).dimensions(x, y + i * 24, buttonWidth, 20).build());
            i++;
            if (i >= 12) break;
        }

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), button -> this.close())
                .dimensions(x, y + i * 24 + 8, buttonWidth, 20)
                .build());
    }
}
